// PROGRAMMER:  Komasquin A. Lopez
// PANTHERID:   5959569
// CLASS:       COP 4655
// INSTRUCTOR:  Steve Luis
// ASSIGNMENT:  #5 Programming Assignment
// DUE:         Sunday 11/17/19
//

import Foundation
import UIKit

class PinViewController: UIViewController {
    var model = ModelClass.instance
    //pinPad label variable
    @IBOutlet var pinPad: UILabel!
    //used for error message
        let alert = UIAlertController(title: "Wrong Pin", message: "The pin is wrong. Enter a new one.", preferredStyle: .alert)
   
    override func viewDidLoad() {
        super.viewDidLoad()
        updatePinDisplay()
        alert.addAction(UIAlertAction(title: "Hello!!", style: .default, handler: {action in self.clearPad()}))
    }

    override func viewWillAppear(_ animated: Bool) {
        clearPad()
    }
    //buttons communicate with this action
    @IBAction func ButtonPressed(_ sender:  UIButton) {
        if (model.addPin(digit: String(sender.tag))) {
            updatePinDisplay()
            if let isCorrect = model.cPin() {
                if(isCorrect) {
                    self.tabBarController?.selectedIndex = 1
                }
                else {
                    self.present(alert, animated: true)
                }
            }
        }
    }
    //was a button to clear, but over time was phased out
    //used above in error message and viewwillappear
    @IBAction func clearPad() {
        model.codeWhip()
        updatePinDisplay()
    }
    //updates UIlabel with model class temp code var
    func updatePinDisplay() {
        pinPad.text = model.codeHolderVar
    }
    
}
