// PROGRAMMER:  Komasquin A. Lopez
// PANTHERID:   5959569
// CLASS:       COP 4655
// INSTRUCTOR:  Steve Luis
// ASSIGNMENT:  #5 Programming Assignment
// DUE:         Sunday 11/17/19
//

import Foundation
import UIKit

class EditViewController: UITableViewController{
    //call to singleton modelClass
    var model = ModelClass.instance
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //reload the tableView when updated
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }
    //used to segue to the viewController to edit or add
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // If the triggered segue is the "ShowItem" segue
        switch segue.identifier {
        case "EditTab"?:
            // Figure out which row was just tapped
            if let row = tableView.indexPathForSelectedRow?.row {
                
                // Get the item associated with this row and pass it along
                let item = model.Stuffs[row]
                let detailViewController = segue.destination as! EditView
                detailViewController.codie = item
                detailViewController.newPepe = false
            }
            
        case "addCodiee"?:
            let detailViewController = segue.destination as! EditView
            detailViewController.codie = code(codeHolder: "", webHolder: "", key: UUID().uuidString)
            detailViewController.newPepe = true
        default:
            preconditionFailure("Unexpected segue identifier.")
        }
    }
    //used to grab number of items for cells
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return model.Stuffs.count
    }
    //mandatory for table view
    override func tableView(_ tableView: UITableView,
                            cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Create an instance of UITableViewCell, with default appearance
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell2",
                                                 for: indexPath)
        
        // Set the text on the cell with the description of the item
        // that is at the nth index of items, where n = row this cell
        // will appear in on the tableview
        
        let item = model.Stuffs[indexPath.row]
        
        cell.textLabel?.text = "\(item.codeHolder + " " + item.webHolder)"
        
        return cell
    }
    
}

