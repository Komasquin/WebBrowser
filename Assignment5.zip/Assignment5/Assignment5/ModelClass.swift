// PROGRAMMER:  Komasquin A. Lopez
// PANTHERID:   5959569
// CLASS:       COP 4655
// INSTRUCTOR:  Steve Luis
// ASSIGNMENT:  #5 Programming Assignment
// DUE:         Sunday 11/17/19
//

import Foundation
struct code{
    var codeHolder: String
    var webHolder: String
    var key: String
}
final class ModelClass {
    //instance for singleton
    static let instance = ModelClass()
    //this is my array of websites and there code
    var Stuffs: [code] = []
    //temp var for code
    var codeHolderVar = ""
    //flag for shange of website
    var update = false
    //temp var for web
    var curWeb = "https://www.google.com"
    
    
    init() {
//make array with three objects in it
        Stuffs.append(contentsOf: [code(codeHolder: "1111", webHolder: "https://my.fiu.edu", key: UUID().uuidString) , code(codeHolder: "1114", webHolder: "https://canvas.fiu.edu", key: UUID().uuidString), code(codeHolder: "1113", webHolder: "https://www.gmail.com", key: UUID().uuidString)])
    }
    //add an object to array "Stuffs"
    func addCode(dowgDogDogDog: code) -> code {
        let newWeb = dowgDogDogDog
        Stuffs.append(newWeb)
        return newWeb
    }
    //edit an object in "Stuffs" array
    func editCode(c: code){
        var i = 0
      //  let index = Stuffs.index(where: {$0.key == k})!
        for stuff in Stuffs {
            if (stuff.webHolder == c.webHolder){
                Stuffs.remove(at: i )
                Stuffs.insert(c, at: i)
            }else if (stuff.codeHolder == c.codeHolder){
                Stuffs.remove(at: i)
                Stuffs.insert(c, at: i)
            }else{
            i += 1
            }
        }
        
        
    }
    //whipe the UIlabel in pinViewController
    func codeWhip() {
        codeHolderVar  = ""
        //webHolder = ""
        print("Browser Wiped")
    }
    //add to pin and used to check if pin is 4 caracters long
    func addPin (digit: String) -> Bool{
        if(codeHolderVar.count < 4) {
            codeHolderVar.append(digit)
            return true
        }
        return false
    }
    //checks if there is a pin and changes the web address to the pin
    func cPin () -> Bool? {
        if(codeHolderVar.count >= 4) {
            if let website = Stuffs.first(where: {$0.codeHolder == codeHolderVar})?.webHolder {
                curWeb = website
                update = true
                print(". Pin \(codeHolderVar) matched to \(website)")
                return true
            }
            else {
                print(". Pin \(codeHolderVar) is invalid")
                return false
            }
        }

        return nil
    }
    //used for the UIlabel in Browser
    func hyperLinkRow() -> String {
        let correspondingPin = Stuffs.first(where: {$0.webHolder == curWeb})?.codeHolder
        return "\(correspondingPin ?? codeHolderVar) | \(curWeb)"
    }
    
}
