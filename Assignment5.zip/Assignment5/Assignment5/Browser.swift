// PROGRAMMER:  Komasquin A. Lopez
// PANTHERID:   5959569
// CLASS:       COP 4655
// INSTRUCTOR:  Steve Luis
// ASSIGNMENT:  #5 Programming Assignment
// DUE:         Sunday 11/17/19
//

import Foundation
import UIKit

class Browser: UIViewController {
    //call to modelClass
    let model = ModelClass.instance
    
    @IBOutlet var labelURL: UILabel!
    //displays the url
    override func viewWillAppear(_ animated: Bool) {
        labelURL.text = model.hyperLinkRow()
        
    }
    
}
