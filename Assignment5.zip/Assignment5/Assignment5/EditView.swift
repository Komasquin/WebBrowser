// PROGRAMMER:  Komasquin A. Lopez
// PANTHERID:   5959569
// CLASS:       COP 4655
// INSTRUCTOR:  Steve Luis
// ASSIGNMENT:  #5 Programming Assignment
// DUE:         Sunday 11/17/19
//

import Foundation
import UIKit

class EditView: UIViewController {
    //used to access modelcALSS
    var model = ModelClass.instance
    //TEXTLABEL VARIABLES for viewController
    @IBOutlet var codeTextLabel: UITextField!
    @IBOutlet var webTextLabel: UITextField!
    //used to access variables on type code
    var codie: code!
    //edit button variable
    var isEdit = true
    //edit and add button variable
    var newPepe :Bool? = false
    
    //programmatically implement the edit button
    //sets text fields to not allow edit and displays value in them
    override func viewDidLoad() {
        super.viewDidLoad()
        codeTextLabel.text = codie.codeHolder
        webTextLabel.text = codie.webHolder
        if newPepe! == false {
            codeTextLabel.isUserInteractionEnabled = false
            webTextLabel.isUserInteractionEnabled = false
            navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Edit" , style: .plain , target: self , action: #selector(editTapped))
    }
    }
    //if edit is tapped sets fields to changable and back to not changeable
    @objc func editTapped(){
        
        if isEdit {
            codeTextLabel.isUserInteractionEnabled = true
            webTextLabel.isUserInteractionEnabled = true
            isEdit = false
        } else if !isEdit{
            codeTextLabel.isUserInteractionEnabled = false
            webTextLabel.isUserInteractionEnabled = false
        }
    }
    //if new add a new object to array; if not new over write existing object
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        view.endEditing(true)
        codie.codeHolder = codeTextLabel.text ?? ""
        codie.webHolder = webTextLabel.text ?? ""
        if (newPepe == false){
            model.editCode(c: codie)
        } else if (newPepe == true) {
        model.addCode(dowgDogDogDog: codie)
        }
    }
    
}
