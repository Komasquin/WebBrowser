// PROGRAMMER:  Komasquin A. Lopez
// PANTHERID:   5959569
// CLASS:       COP 4655
// INSTRUCTOR:  Steve Luis
// ASSIGNMENT:  #5 Programming Assignment
// DUE:         Sunday 11/17/19
//
import WebKit
import Foundation
import UIKit

class WebKitViewController: UIViewController, WKNavigationDelegate {
    //used to reach model
    let model = ModelClass.instance
    var webView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let url = URL(string: model.curWeb)!
        webView.load(URLRequest(url: url))
        webView.allowsBackForwardNavigationGestures = true
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if(model.update)
        {
            let url = URL(string: model.curWeb)!
            webView.load(URLRequest(url: url))
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func loadView() {
        webView = WKWebView()
        webView.navigationDelegate = self
        view = webView
    }
    
}
